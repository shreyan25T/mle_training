# mle_training# Mle_Training

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)
[![Python 3.8](https://img.shields.io/badge/python-3.8-blue.svg)](https://www.python.org/downloads/release/python-360/)

## Usage:-

- instructions to run the code <br>
- Create required Anaconda environment conda create --name environmentName python=3 pandas numpy. <br>
- Include all your dependencies at once while creating the environment. <br>
- Switch to the environment with conda activate environmentName. <br>
- Clone my repository. <br>
- Open CMD in working directory.
- Run following command.
  ```
  pip install -r requirements.yaml
  ```
- Executing the python script python fileName.py <br>
