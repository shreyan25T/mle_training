import unittest
from score import get_predictions


class Testscore(unittest.TestCase):

    def test_score(self):
        self.assertTrue(get_predictions)


if __name__ == "__main__":
    unittest.main()
